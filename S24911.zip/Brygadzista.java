public class Brygadzista extends Uzytkownik{

}
