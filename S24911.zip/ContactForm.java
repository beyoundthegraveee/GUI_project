import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Date;

class ContactForm extends JFrame {
    JTextField login_field;
    JPasswordField haslo_field;


    public ContactForm() {

        super("Login field");
        super.setBounds(600, 300, 300, 300);

        Container container = super.getContentPane();
        container.setLayout(null);
        super.setResizable(false);

        JLabel login = new JLabel("login");
        login_field = new JTextField();
        JLabel haslo = new JLabel("hasło");
        haslo_field = new JPasswordField();

        login.setBounds(10,30,70,40);
        haslo.setBounds(10,90,70,40);
        login_field.setBounds(80,30,140,40);
        haslo_field.setBounds(80,90,140,40);



        container.add(login);
        container.add(login_field);
        container.add(haslo);
        container.add(haslo_field);


        JButton jButton = new JButton("Enter");
        jButton.setBounds(90,190,100,40);
        jButton.setSelected(true);
        container.add(jButton);
        jButton.addActionListener(new AddWindow());
    }


    class AddWindow extends Uzytkownik implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent actionEvent) {
            if (login_field.getText().equals(login1) && haslo_field.getText().equals(password1) || login_field.getText().equals(login2) && haslo_field.getText().equals(password2)) {
                JOptionPane.showMessageDialog(null, "Welcome!");
                Main_Window.Main_Window();
                log("CorrectLogin.txt", login_field.getText(), haslo_field.getText());

                login_field.setText("");
                haslo_field.setText("");
                login_field.requestFocus();


            } else {

                log("IncorrectLogin.txt", login_field.getText(), haslo_field.getText());
                JOptionPane.showMessageDialog(null, "Invalid name or password");

                login_field.setText("");
                haslo_field.setText("");
                login_field.requestFocus();
            }
        }



    }


    public void log(String filename, String login, String password) {
        try {
            FileWriter fout = new FileWriter(filename, true);
            PrintWriter data = new PrintWriter(fout);
            Date now = new Date();
            String time = now.toString();
            data.println(time + "," + login + "," + password);
            data.close();
        } catch (Exception e) {
            System.out.println("Error");
        }
    }

}
