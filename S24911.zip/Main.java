public class DzialPracownikow {
    private String name;
}
