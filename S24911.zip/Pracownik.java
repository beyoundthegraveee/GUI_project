public class Praca {
    int NumerPracy;
    int CzasPracy;
    boolean Zrealizowane;
    String opis;
    enum RodzajPracy{ Ogólna, Montaż, Demontaż, Wymiana};


}
