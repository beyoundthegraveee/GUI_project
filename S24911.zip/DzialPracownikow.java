import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.List;

class Main_Window {

    static DefaultListModel model1 = new DefaultListModel();
    static DefaultListModel model2 = new DefaultListModel();
    static DefaultListModel model3 = new DefaultListModel();
    static DefaultListModel model4 = new DefaultListModel();
    static DefaultListModel model5 = new DefaultListModel();
    static DefaultListModel model6 = new DefaultListModel();
    static DefaultListModel model7 = new DefaultListModel();


    public static int arg = 0;


    public static boolean Main_Window() {

        JFrame frame = new JFrame();
        JPanel panel = new JPanel();
        JPanel panel1 = new JPanel();
        JList list1 = new JList();
        JList list2 = new JList();
        JList list3 = new JList();
        JList list4 = new JList();
        JList list5 = new JList();
        JList list6 = new JList();
        JList list7 = new JList();


        list1.setModel(model1);
        list2.setModel(model2);
        list3.setModel(model3);
        list4.setModel(model4);
        list5.setModel(model5);
        list6.setModel(model6);
        list7.setModel(model7);
        panel1.setLayout(new BoxLayout(panel1, BoxLayout.X_AXIS));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationByPlatform(true);
        frame.setResizable(false);
        frame.setBounds(500, 150, 700, 600);
        panel.setBounds(0, 90, 200, 450);
        panel1.setBounds(140, -10, 500, 100);
        list1.setBounds(200, 90, 400, 440);
        list2.setBounds(200, 90, 400, 440);
        list3.setBounds(200, 90, 400, 440);
        list4.setBounds(200, 90, 400, 440);
        list5.setBounds(200, 90, 400, 440);
        list6.setBounds(200, 90, 400, 440);
        list7.setBounds(200, 90, 400, 440);
        frame.setLayout(null);
        frame.add(panel);
        frame.add(panel1);
        frame.add(list1);
        frame.add(list2);
        frame.add(list3);
        frame.add(list4);
        frame.add(list5);
        frame.add(list6);


        JButton jButton1 = new JButton("Dział Pracownikow ");
        JButton jButton2 = new JButton("Pracownik ");
        JButton jButton3 = new JButton("Uzytkownik");
        JButton jButton4 = new JButton(" Brygadzista");
        JButton jButton5 = new JButton("Brygada");
        JButton jButton6 = new JButton("Zlecenie");
        JButton jButton7 = new JButton("Wyloguj");
        JButton jButton13 = new JButton("Praca");

        JButton jButton8 = new JButton("Nowy");
        JButton jButton9 = new JButton("Edycja");
        JButton jButton10 = new JButton("Usuń");
        JButton jButton11 = new JButton("Pracownicy działu");
        JButton jButton12 = new JButton("Witaj");


        panel.add(jButton1);
        panel.add(jButton2);
        panel.add(jButton3);
        panel.add(jButton4);
        panel.add(jButton5);
        panel.add(jButton6);
        panel.add(jButton7);
        panel.add(jButton13);


        panel1.add(jButton8);
        panel1.add(jButton9);
        panel1.add(jButton10);
        panel1.add(jButton11);
        panel1.add(jButton12);


        jButton1.setMaximumSize(new Dimension(145, 40));


        jButton2.setMaximumSize(new Dimension(145, 40));


        jButton3.setMaximumSize(new Dimension(145, 40));


        jButton4.setMaximumSize(new Dimension(145, 40));


        jButton5.setMaximumSize(new Dimension(145, 40));


        jButton6.setMaximumSize(new Dimension(145, 40));


        jButton7.setMaximumSize(new Dimension(145, 40));

        jButton8.setMaximumSize(new Dimension(125, 40));

        jButton9.setMaximumSize(new Dimension(125, 40));

        jButton10.setMaximumSize(new Dimension(125, 40));

        jButton11.setMaximumSize(new Dimension(125, 40));

        jButton12.setMaximumSize(new Dimension(125, 40));

        jButton13.setMaximumSize(new Dimension(145, 40));


        panel.add(jButton1);
        panel.add(Box.createRigidArea(new Dimension(15, 30)));
        panel.add(jButton2);

        panel.add(jButton2);
        panel.add(Box.createRigidArea(new Dimension(15, 30)));
        panel.add(jButton3);

        panel.add(jButton3);
        panel.add(Box.createRigidArea(new Dimension(15, 30)));
        panel.add(jButton4);

        panel.add(jButton4);
        panel.add(Box.createRigidArea(new Dimension(15, 30)));
        panel.add(jButton5);

        panel.add(jButton5);
        panel.add(Box.createRigidArea(new Dimension(15, 30)));
        panel.add(jButton6);

        panel.add(jButton6);
        panel.add(Box.createRigidArea(new Dimension(15, 30)));
        panel.add(jButton13);

        panel.add(jButton13);
        panel.add(Box.createRigidArea(new Dimension(15, 30)));
        panel.add(jButton7);

        panel1.add(jButton8);
        panel1.add(Box.createRigidArea(new Dimension(25, 15)));
        panel1.add(jButton9);

        panel1.add(jButton9);
        panel1.add(Box.createRigidArea(new Dimension(25, 15)));
        panel1.add(jButton10);

        panel1.add(jButton10);
        panel1.add(Box.createRigidArea(new Dimension(25, 15)));
        panel1.add(jButton11);

        panel1.add(jButton11);
        panel1.add(Box.createRigidArea(new Dimension(25, 15)));
        panel1.add(jButton12);


        jButton1.setBackground(Color.WHITE);
        jButton2.setBackground(Color.WHITE);
        jButton3.setBackground(Color.WHITE);
        jButton4.setBackground(Color.WHITE);
        jButton5.setBackground(Color.WHITE);
        jButton6.setBackground(Color.WHITE);
        jButton7.setBackground(Color.WHITE);
        jButton13.setBackground(Color.WHITE);


        jButton8.setBackground(Color.BLUE);
        jButton9.setBackground(Color.BLUE);
        jButton10.setBackground(Color.BLUE);
        jButton11.setBackground(Color.BLUE);
        jButton12.setBackground(Color.WHITE);


        jButton1.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        jButton2.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        jButton3.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        jButton4.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        jButton5.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        jButton6.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        jButton7.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        jButton13.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));

        jButton8.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
        jButton9.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
        jButton10.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
        jButton11.setBorder(BorderFactory.createLineBorder(Color.blue, 1));
        jButton12.setBorder(BorderFactory.createLineBorder(Color.black, 1));

        list1.setLayoutOrientation(JList.VERTICAL);

        jButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                 arg = 2;
                    list1.setVisible(true);
                    list2.setVisible(false);
                    list3.setVisible(false);
                    list4.setVisible(false);
                    list5.setVisible(false);
                    list6.setVisible(false);

            }

        });



        jButton2.addActionListener(actionEvent -> {
             arg =1;
            list1.setVisible(false);
            list2.setVisible(true);
            list3.setVisible(false);
            list4.setVisible(false);
            list5.setVisible(false);
            list6.setVisible(false);

        });

        jButton3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                arg = 3;

                list3.setVisible(true);
                list1.setVisible(false);
                list2.setVisible(false);
                list4.setVisible(false);
                list5.setVisible(false);
                list6.setVisible(false);
            }

        });

        jButton4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                arg = 5;


                list3.setVisible(false);
                list4.setVisible(true);
                list1.setVisible(false);
                list2.setVisible(false);
                list5.setVisible(false);
                list6.setVisible(false);
            }

        });

        jButton5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                 arg = 4;
                list4.setVisible(false);
                list5.setVisible(true);
                list1.setVisible(false);
                list2.setVisible(false);
                list3.setVisible(false);
                list6.setVisible(false);

            }
        });


        jButton6.addActionListener(actionEvent -> {


            list5.setVisible(false);
            list6.setVisible(true);
            list1.setVisible(false);
            list2.setVisible(false);
            list3.setVisible(false);
            list4.setVisible(false);

        });
        jButton7.addActionListener(actionEvent -> frame.setVisible(false));

        jButton8.addActionListener(new ActionListener() {


            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                if(arg == 0){
                    JOptionPane.showMessageDialog(null,"Wybierz pole");
                }
                if (arg == 1) {
                    JFrame frame1 = new JFrame();
                    frame1.setResizable(false);


                    JTextField text = new JTextField();
                    JTextField text1 = new JTextField();
                    JTextField text2 = new JTextField();

                    JButton jButton = new JButton("Submit");
                    JLabel label1 = new JLabel("Name");
                    JLabel label2 = new JLabel("Surname");
                    JLabel label3 = new JLabel("Birth date");
                    JLabel label4 = new JLabel("Dzial");
                    frame1.add(list1);
                    list1.setBounds(120,220,100,100);
                    list1.setVisible(true);



                    frame1.setBounds(650, 300, 300, 400);


                    text.setBounds(70, 40, 130, 40);
                    text1.setBounds(70, 100, 130, 40);
                    text2.setBounds(70, 160, 130, 40);



                    label1.setBounds(5, 40, 100, 40);
                    label2.setBounds(5, 100, 100, 40);
                    label3.setBounds(5, 160, 100, 40);
                    label4.setBounds(5, 220, 100, 40);
                    jButton.setBounds(10, 280, 90, 30);
                    frame1.add(jButton);
                    frame1.add(label1);
                    frame1.add(label2);
                    frame1.add(label3);
                    frame1.add(label4);
                    frame1.add(text);
                    frame1.add(text1);
                    frame1.add(text2);
                    frame1.setLayout(null);
                    frame1.setVisible(true);

                    jButton.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent actionEvent) {


                            String str = text.getText();
                            String str1 = text1.getText();
                            String str2 = text2.getText();
                            String str3 = String.valueOf(list1.getSelectedValuesList());
                            if (str.equals("") || str.equalsIgnoreCase("Field can not be empty") || str1.equals("") || str1.equalsIgnoreCase("Field can not be empty") || str2.equals("") || str2.equalsIgnoreCase("Field can not be empty")|| str3.equals("") || str3.equalsIgnoreCase("Field can not be empty")) {
                                JOptionPane.showMessageDialog(null, "Field can not be empty");
                            } else {

                                list2.setModel(model2);
                                model2.addElement(str + " " + str1 + " " + str2+ " " + str3 );
                                text.setText("");
                                text1.setText("");
                                text2.setText("");
                            }

                            int val = list2.getModel().getSize();
                            PrintWriter writer = null;
                            try {
                                writer = new PrintWriter("Pracownik.txt");
                                writer.println(val);

                                for (int i = 0; i < val; i++) {
                                    writer.println(list2.getModel().getElementAt(i));
                                }
                            } catch (Exception e) {
                                System.out.println("" + e);
                            } finally {
                                writer.close();
                            }

                            frame1.setVisible(false);

                        }
                    });

                }
                if(arg == 2){
                    JFrame frame1 = new JFrame();
                    JTextField jTextField = new JTextField();
                    JButton jButton = new JButton("Submit");
                    JLabel label = new JLabel("Nazwa działu:");
                    label.setBounds(20, 50, 100, 40);
                    jTextField.setBounds(130, 50, 100, 40);
                    jButton.setBounds(150, 100, 80, 30);
                    frame1.setBounds(550, 300, 300, 200);
                    frame1.add(jTextField);
                    frame1.add(label);
                    frame1.add(jButton);
                    frame1.setResizable(false);
                    frame1.setLayout(null);
                    frame1.setVisible(true);
                    jButton.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent actionEvent) {
                            String str1 = jTextField.getText();
                            if (str1.equals("") || str1.equalsIgnoreCase("Field can not be empty")) {
                                JOptionPane.showMessageDialog(null, "Field can not be empty");
                            } else {
                                model1.addElement(str1);
                                String val = jTextField.getText();
                                PrintWriter writer = null;
                                try {
                                    writer = new PrintWriter("DzialPracownikow.txt");
                                    writer.println(val);
                                } catch (Exception e) {
                                    System.out.println("" + e);
                                } finally {
                                    writer.close();
                                    frame1.setVisible(false);
                                }
                            }
                        }

                });
                }
                if (arg ==3){
                    JFrame frame = new JFrame();
                    JTextField newLogin = new JTextField();
                    JTextField newPassword = new JTextField();
                    JLabel jLabel = new JLabel("New Login");
                    JLabel jLabel1 = new JLabel("New Hasło");
                    JButton jButton = new JButton("Make");
                    frame.setResizable(false);
                    frame.setBounds(550, 300, 300, 250);
                    jLabel.setBounds(10, 20, 100, 40);
                    jLabel1.setBounds(10,80,100,40);
                    newLogin.setBounds(120, 20, 100, 40);
                    newPassword.setBounds(120, 80, 100, 40);
                    jButton.setBounds(100, 130, 80, 30);
                    frame.setLayout(null);


                    frame.add(jButton);
                    frame.add(jLabel);
                    frame.add(jLabel1);
                    frame.add(newLogin);
                    frame.add(newPassword);
                    frame.setVisible(true);


                    jButton.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent actionEvent) {
                            String val = newPassword.getText();
                            String val1 = newLogin.getText();
                            if (newLogin.getText().equals("") || newLogin.getText().equalsIgnoreCase("Type here") || newPassword.getText().equals("") || newPassword.getText().equalsIgnoreCase("Type here")) {
                                JOptionPane.showMessageDialog(null, "Field can not be empty");
                            }else {
                                list3.setModel(model3);
                                model3.addElement(newLogin+" "+ newPassword);
                                PrintWriter writer = null;
                                try {
                                    writer = new PrintWriter("Użytkownik.txt");
                                    writer.println(val);
                                    writer.println(val1);
                                } catch (Exception e) {
                                    System.out.println("" + e);
                                } finally {
                                    writer.close();
                                }
                                frame.setVisible(false);
                            }
                        }
                    });
                }

                if(arg == 5){
                    JFrame frame3 = new JFrame();
                    JButton jButton = new JButton("Make");
                    frame3.setResizable(false);
                    frame3.add(list2);

                    jButton.setBounds(60, 140, 80, 30);
                    frame3.setBounds(550, 300, 250, 250);
                    list2.setBounds(40,30,160,100);
                    list2.setVisible(true);

                    frame3.add(jButton);
                    frame3.setLayout(null);
                    frame3.setVisible(true);
                    jButton.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent actionEvent) {
                            String val1 = String.valueOf(list2.getSelectedValuesList());
                            if (val1.equals("") || val1.equalsIgnoreCase("Field can not be empty")) {
                                JOptionPane.showMessageDialog(null, "Field can not be empty");
                            } else {
                                list4.setModel(model4);
                                model4.addElement(val1);
                                PrintWriter writer = null;
                                try {
                                    writer = new PrintWriter("Brygadzista.txt");
                                    writer.println(val1);
                                } catch (Exception e) {
                                    System.out.println("" + e);
                                } finally {
                                    writer.close();
                                }
                            }
                            frame3.setVisible(false);
                        }
                    });
                }



                if(arg == 4){
                    JFrame frame2 = new JFrame();
                    JTextField jTextField = new JTextField();
                    JButton jButton = new JButton("Submit");
                    JLabel label = new JLabel("Nazwa Brygady");
                    frame2.setResizable(false);
                    frame2.add(list2);


                    label.setBounds(20, 20, 100, 40);
                    jTextField.setBounds(130, 20, 100, 40);
                    jButton.setBounds(250, 40, 80, 30);
                    frame2.setBounds(550, 300, 350, 300);
                    list2.setBounds(130,100,100,120);
                    list2.setVisible(true);
                    frame2.add(jTextField);
                    frame2.add(label);
                    frame2.add(jButton);
                    frame2.setLayout(null);
                    frame2.setVisible(true);
                    jButton.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent actionEvent) {
                            String val = jTextField.getText();
                            String val1 = String.valueOf(list2.getSelectedValuesList());
                            if (val.equals("") || val.equalsIgnoreCase("Field can not be empty") || val1.equals("") || val1.equalsIgnoreCase("Field can not be empty")) {
                                JOptionPane.showMessageDialog(null, "Field can not be empty");
                            } else {
                                list5.setModel(model5);
                                model5.addElement(val + " " + val1);
                                PrintWriter writer = null;
                                try {
                                    writer = new PrintWriter("Brygada.txt");
                                    writer.println(val);
                                } catch (Exception e) {
                                    System.out.println("" + e);
                                } finally {
                                    writer.close();
                                }
                            }

                            frame2.setVisible(false);
                        }
                    });
                }



                }
            });
        jButton10.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                if (arg == 0){
                    JOptionPane.showMessageDialog(null, "Wybierz pole");
                }

                if(arg== 1) {
                    List selectedItems = list2.getSelectedValuesList();
                    for (Object o : selectedItems) {
                        model2.removeElement(o);
                    }

                    {
                        JOptionPane.showMessageDialog(null, "Deleted");
                    }


                    try {
                        String data= null;
                        File file=new File("DzialPracownikow.txt");
                        FileReader fr =new FileReader(file);
                        BufferedReader br = new BufferedReader(fr);
                        while((data=br.readLine())!= null) {
                            String[] de = data.split(" ");
                            if(de[0].equals( selectedItems)) {
                                data.trim();
                            }
                            br.close();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }



                if (arg == 2){
                    List selectedItems = list1.getSelectedValuesList();
                    for (Object o : selectedItems) {
                        model1.removeElement(o);
                    }

                    {
                        JOptionPane.showMessageDialog(null, "Deleted");
                    }






                }
                if(arg == 3){
                    List selectedItems = list3.getSelectedValuesList();
                    for (Object o : selectedItems) {
                        model3.removeElement(o);
                    }

                    {
                        JOptionPane.showMessageDialog(null, "Deleted");
                    }

                }
                if(arg == 4){
                    List selectedItems = list5.getSelectedValuesList();
                    for (Object o : selectedItems) {
                        model5.removeElement(o);
                    }

                    {
                        JOptionPane.showMessageDialog(null, "Deleted");
                    }

                }


                if(arg == 5) {
                    List selectedItems = list4.getSelectedValuesList();
                    for (Object o : selectedItems) {
                        model4.removeElement(o);
                    }

                    {
                        JOptionPane.showMessageDialog(null, "Deleted");
                    }
                }








                }
        });

        jButton9.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {

                model1.removeElement(list1.getSelectedValue());


            }
        });


        frame.setVisible(true);


        return true;
    }
}