import javax.swing.*;

public class Uzytkownik extends Pracownik {


    String login1 = "Jake";
    String password1 = "12345";
    String login2 = "Sam";
    String password2 = "54321";






}
