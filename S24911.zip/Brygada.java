import java.util.List;

public class Brygada {
    String nazwa;
    Brygadzista brygadzistę;
    List<Pracownik> list;
}
