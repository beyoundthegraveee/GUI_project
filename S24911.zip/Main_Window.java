public class Pracownik {

    String name;
    String surname;
    String DateOfBirth;
    String dzial;
}
